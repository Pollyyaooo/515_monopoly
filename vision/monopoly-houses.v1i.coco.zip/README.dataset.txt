# monopoly-houses > 2026-04-11 8:08pm
https://universe.roboflow.com/yitongs-workspace/monopoly-houses

Provided by a Roboflow user
License: CC BY 4.0

